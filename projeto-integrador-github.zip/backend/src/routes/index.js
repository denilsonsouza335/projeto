const express = require('express');
const router = express.Router();

const produtoController = require('../controllers/produtoController');
const fornecedorController = require('../controllers/fornecedorController');
const associacaoController = require('../controllers/associacaoController');

// Rotas de produtos
router.get('/produtos', produtoController.listar);
router.get('/produtos/:id', produtoController.buscarPorId);
router.post('/produtos', produtoController.criar);
router.put('/produtos/:id', produtoController.atualizar);
router.delete('/produtos/:id', produtoController.remover);

// Rotas de fornecedores
router.get('/fornecedores', fornecedorController.listar);
router.get('/fornecedores/:id', fornecedorController.buscarPorId);
router.post('/fornecedores', fornecedorController.criar);
router.put('/fornecedores/:id', fornecedorController.atualizar);
router.delete('/fornecedores/:id', fornecedorController.remover);

// Rotas de associação N:N
router.get('/associacoes', associacaoController.listar);
router.post('/associacoes', associacaoController.associar);
router.delete('/associacoes/:id', associacaoController.desassociar);
router.get('/produtos/:id/fornecedores', associacaoController.fornecedoresDoProduto);
router.get('/fornecedores/:id/produtos', associacaoController.produtosDoFornecedor);

module.exports = router;
