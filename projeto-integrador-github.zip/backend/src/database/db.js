const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

const defaultDbPath = path.resolve(__dirname, '../../data/database.sqlite');
const dbPath = process.env.DB_PATH
  ? path.resolve(process.cwd(), process.env.DB_PATH)
  : defaultDbPath;

fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Erro ao conectar ao SQLite:', err.message);
  } else {
    console.log('Banco de dados SQLite conectado em:', dbPath);
  }
});

db.serialize(() => {
  db.run('PRAGMA foreign_keys = ON;');

  db.run(`
    CREATE TABLE IF NOT EXISTS produto (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      descricao TEXT,
      preco REAL NOT NULL,
      codigo_barras TEXT UNIQUE
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS fornecedor (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      cnpj TEXT NOT NULL UNIQUE,
      endereco TEXT,
      contato TEXT
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS produto_fornecedor (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      produto_id INTEGER NOT NULL,
      fornecedor_id INTEGER NOT NULL,
      preco_fornecedor REAL,
      prazo_entrega_dias INTEGER,
      UNIQUE(produto_id, fornecedor_id),
      FOREIGN KEY (produto_id) REFERENCES produto(id) ON DELETE CASCADE,
      FOREIGN KEY (fornecedor_id) REFERENCES fornecedor(id) ON DELETE CASCADE
    );
  `);
});

module.exports = db;
