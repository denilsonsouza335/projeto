const db = require('../database/db');

exports.listar = (req, res) => {
  db.all('SELECT * FROM fornecedor ORDER BY id DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.status(200).json(rows);
  });
};

exports.buscarPorId = (req, res) => {
  db.get('SELECT * FROM fornecedor WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ erro: err.message });
    if (!row) return res.status(404).json({ erro: 'Fornecedor não encontrado' });
    res.status(200).json(row);
  });
};

exports.criar = (req, res) => {
  const { nome, cnpj, endereco, contato } = req.body;

  if (!nome || !cnpj) {
    return res.status(400).json({ erro: 'Nome e CNPJ são obrigatórios' });
  }

  const sql = `INSERT INTO fornecedor (nome, cnpj, endereco, contato) VALUES (?, ?, ?, ?)`;
  db.run(sql, [nome, cnpj, endereco || null, contato || null], function (err) {
    if (err) {
      if (err.message.includes('UNIQUE')) {
        return res.status(409).json({ erro: 'CNPJ já cadastrado' });
      }
      return res.status(400).json({ erro: err.message });
    }
    res.status(201).json({
      id: this.lastID,
      nome,
      cnpj,
      endereco: endereco || null,
      contato: contato || null
    });
  });
};

exports.atualizar = (req, res) => {
  const { nome, cnpj, endereco, contato } = req.body;

  if (!nome || !cnpj) {
    return res.status(400).json({ erro: 'Nome e CNPJ são obrigatórios' });
  }

  const sql = `UPDATE fornecedor SET nome = ?, cnpj = ?, endereco = ?, contato = ? WHERE id = ?`;
  db.run(sql, [nome, cnpj, endereco || null, contato || null, req.params.id], function (err) {
    if (err) {
      if (err.message.includes('UNIQUE')) {
        return res.status(409).json({ erro: 'CNPJ já cadastrado' });
      }
      return res.status(400).json({ erro: err.message });
    }
    if (this.changes === 0) return res.status(404).json({ erro: 'Fornecedor não encontrado' });
    res.status(200).json({ mensagem: 'Fornecedor atualizado com sucesso' });
  });
};

exports.remover = (req, res) => {
  db.run('DELETE FROM fornecedor WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ erro: err.message });
    if (this.changes === 0) return res.status(404).json({ erro: 'Fornecedor não encontrado' });
    res.status(204).send();
  });
};
