const db = require('../database/db');

exports.listar = (req, res) => {
  const sql = `
    SELECT
      pf.id,
      p.id AS produto_id,
      p.nome AS produto_nome,
      f.id AS fornecedor_id,
      f.nome AS fornecedor_nome,
      pf.preco_fornecedor,
      pf.prazo_entrega_dias
    FROM produto_fornecedor pf
    JOIN produto p ON p.id = pf.produto_id
    JOIN fornecedor f ON f.id = pf.fornecedor_id
    ORDER BY pf.id DESC
  `;
  db.all(sql, [], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.status(200).json(rows);
  });
};

exports.associar = (req, res) => {
  const { produto_id, fornecedor_id, preco_fornecedor, prazo_entrega_dias } = req.body;

  if (!produto_id || !fornecedor_id) {
    return res.status(400).json({ erro: 'Informe o ID do produto e o ID do fornecedor' });
  }

  const sql = `
    INSERT INTO produto_fornecedor (produto_id, fornecedor_id, preco_fornecedor, prazo_entrega_dias)
    VALUES (?, ?, ?, ?)
  `;
  db.run(
    sql,
    [
      produto_id,
      fornecedor_id,
      preco_fornecedor === '' || preco_fornecedor === undefined ? null : Number(preco_fornecedor),
      prazo_entrega_dias === '' || prazo_entrega_dias === undefined ? null : Number(prazo_entrega_dias)
    ],
    function (err) {
      if (err) {
        if (err.message.includes('UNIQUE')) {
          return res.status(409).json({ erro: 'Esta associação já existe' });
        }
        return res.status(400).json({ erro: err.message });
      }
      res.status(201).json({ id: this.lastID, produto_id, fornecedor_id });
    }
  );
};

exports.desassociar = (req, res) => {
  db.run('DELETE FROM produto_fornecedor WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ erro: err.message });
    if (this.changes === 0) return res.status(404).json({ erro: 'Associação não encontrada' });
    res.status(204).send();
  });
};

exports.fornecedoresDoProduto = (req, res) => {
  const sql = `
    SELECT f.*, pf.preco_fornecedor, pf.prazo_entrega_dias
    FROM fornecedor f
    JOIN produto_fornecedor pf ON pf.fornecedor_id = f.id
    WHERE pf.produto_id = ?
  `;
  db.all(sql, [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.status(200).json(rows);
  });
};

exports.produtosDoFornecedor = (req, res) => {
  const sql = `
    SELECT p.*, pf.preco_fornecedor, pf.prazo_entrega_dias
    FROM produto p
    JOIN produto_fornecedor pf ON pf.produto_id = p.id
    WHERE pf.fornecedor_id = ?
  `;
  db.all(sql, [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.status(200).json(rows);
  });
};
