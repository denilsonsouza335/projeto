const db = require('../database/db');

exports.listar = (req, res) => {
  db.all('SELECT * FROM produto ORDER BY id DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.status(200).json(rows);
  });
};

exports.buscarPorId = (req, res) => {
  db.get('SELECT * FROM produto WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ erro: err.message });
    if (!row) return res.status(404).json({ erro: 'Produto não encontrado' });
    res.status(200).json(row);
  });
};

exports.criar = (req, res) => {
  const { nome, descricao, preco, codigo_barras } = req.body;
  const precoNumerico = Number(preco);

  if (!nome || preco === undefined || preco === '' || !Number.isFinite(precoNumerico)) {
    return res.status(400).json({ erro: 'Nome e preço válido são obrigatórios' });
  }

  const sql = `INSERT INTO produto (nome, descricao, preco, codigo_barras) VALUES (?, ?, ?, ?)`;
  db.run(sql, [nome, descricao || null, precoNumerico, codigo_barras || null], function (err) {
    if (err) return res.status(400).json({ erro: err.message });
    res.status(201).json({
      id: this.lastID,
      nome,
      descricao: descricao || null,
      preco: precoNumerico,
      codigo_barras: codigo_barras || null
    });
  });
};

exports.atualizar = (req, res) => {
  const { nome, descricao, preco, codigo_barras } = req.body;
  const precoNumerico = Number(preco);

  if (!nome || preco === undefined || preco === '' || !Number.isFinite(precoNumerico)) {
    return res.status(400).json({ erro: 'Nome e preço válido são obrigatórios' });
  }

  const sql = `UPDATE produto SET nome = ?, descricao = ?, preco = ?, codigo_barras = ? WHERE id = ?`;
  db.run(
    sql,
    [nome, descricao || null, precoNumerico, codigo_barras || null, req.params.id],
    function (err) {
      if (err) return res.status(400).json({ erro: err.message });
      if (this.changes === 0) return res.status(404).json({ erro: 'Produto não encontrado' });
      res.status(200).json({ mensagem: 'Produto atualizado com sucesso' });
    }
  );
};

exports.remover = (req, res) => {
  db.run('DELETE FROM produto WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ erro: err.message });
    if (this.changes === 0) return res.status(404).json({ erro: 'Produto não encontrado' });
    res.status(204).send();
  });
};
