import React, { useState, useEffect } from 'react';
import api from '../services/api';

function Associacoes() {
  const [produtos, setProdutos] = useState([]);
  const [fornecedores, setFornecedores] = useState([]);
  const [associacoes, setAssociacoes] = useState([]);
  const [produtoId, setProdutoId] = useState('');
  const [fornecedorId, setFornecedorId] = useState('');
  const [precoFornecedor, setPrecoFornecedor] = useState('');
  const [prazoDias, setPrazoDias] = useState('');
  const [mensagem, setMensagem] = useState('');

  const carregarDados = async () => {
    try {
      const [resProd, resForn, resAssoc] = await Promise.all([
        api.get('/produtos'),
        api.get('/fornecedores'),
        api.get('/associacoes')
      ]);
      setProdutos(resProd.data);
      setFornecedores(resForn.data);
      setAssociacoes(resAssoc.data);
    } catch (err) {
      setMensagem('Erro ao carregar dados do servidor.');
    }
  };

  useEffect(() => {
    carregarDados();
  }, []);

  const handleAssociar = async (e) => {
    e.preventDefault();
    if (!produtoId || !fornecedorId) {
      setMensagem('Selecione tanto um produto quanto um fornecedor.');
      return;
    }

    try {
      await api.post('/associacoes', {
        produto_id: produtoId,
        fornecedor_id: fornecedorId,
        preco_fornecedor: precoFornecedor ? Number(precoFornecedor) : null,
        prazo_entrega_dias: prazoDias ? Number(prazoDias) : null
      });

      setMensagem('Associação vinculada com sucesso!');
      setProdutoId('');
      setFornecedorId('');
      setPrecoFornecedor('');
      setPrazoDias('');
      carregarDados();
    } catch (err) {
      setMensagem(err.response?.data?.erro || 'Erro ao vincular.');
    }
  };

  const handleDesassociar = async (id) => {
    if (!window.confirm('Deseja desvincular este produto deste fornecedor?')) return;
    try {
      await api.delete(`/associacoes/${id}`);
      setMensagem('Vínculo desfeito com sucesso.');
      carregarDados();
    } catch (err) {
      setMensagem('Erro ao desassociar.');
    }
  };

  return (
    <div>
      <h2>Associação Produto / Fornecedor (Muitos para Muitos)</h2>
      {mensagem && <div className="alert" role="alert">{mensagem}</div>}

      <form onSubmit={handleAssociar}>
        <select value={produtoId} onChange={(e) => setProdutoId(e.target.value)} required>
          <option value="">-- Selecione o Produto --</option>
          {produtos.map((produto) => (
            <option key={produto.id} value={produto.id}>
              {produto.nome} (ID: {produto.id})
            </option>
          ))}
        </select>

        <select value={fornecedorId} onChange={(e) => setFornecedorId(e.target.value)} required>
          <option value="">-- Selecione o Fornecedor --</option>
          {fornecedores.map((fornecedor) => (
            <option key={fornecedor.id} value={fornecedor.id}>
              {fornecedor.nome} (CNPJ: {fornecedor.cnpj})
            </option>
          ))}
        </select>

        <input type="number" min="0" step="0.01" placeholder="Preço no Fornecedor (R$)" value={precoFornecedor} onChange={(e) => setPrecoFornecedor(e.target.value)} />
        <input type="number" min="0" placeholder="Prazo Entrega (dias)" value={prazoDias} onChange={(e) => setPrazoDias(e.target.value)} />
        <button type="submit">Vincular Produto ao Fornecedor</button>
      </form>

      <table>
        <thead>
          <tr>
            <th>ID Vínculo</th>
            <th>Produto</th>
            <th>Fornecedor</th>
            <th>Preço Praticado</th>
            <th>Prazo Entrega</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {associacoes.length === 0 ? (
            <tr><td colSpan="6">Nenhuma relação cadastrada até o momento.</td></tr>
          ) : (
            associacoes.map((assoc) => (
              <tr key={assoc.id}>
                <td>{assoc.id}</td>
                <td><strong>{assoc.produto_nome}</strong> (ID: {assoc.produto_id})</td>
                <td>{assoc.fornecedor_nome} (ID: {assoc.fornecedor_id})</td>
                <td>{assoc.preco_fornecedor !== null ? `R$ ${Number(assoc.preco_fornecedor).toFixed(2)}` : '-'}</td>
                <td>{assoc.prazo_entrega_dias !== null ? `${assoc.prazo_entrega_dias} dias` : '-'}</td>
                <td>
                  <button className="btn-danger" onClick={() => handleDesassociar(assoc.id)}>
                    Desassociar
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Associacoes;
