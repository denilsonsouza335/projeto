import React, { useState, useEffect } from 'react';
import api from '../services/api';

const ESTADO_INICIAL = { nome: '', descricao: '', preco: '', codigo_barras: '' };

function Produtos() {
  const [produtos, setProdutos] = useState([]);
  const [form, setForm] = useState(ESTADO_INICIAL);
  const [editandoId, setEditandoId] = useState(null);
  const [mensagem, setMensagem] = useState('');

  const carregarProdutos = async () => {
    try {
      const res = await api.get('/produtos');
      setProdutos(res.data);
    } catch (err) {
      setMensagem('Erro ao carregar produtos. Verifique se o backend está em execução.');
    }
  };

  useEffect(() => {
    carregarProdutos();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editandoId) {
        await api.put(`/produtos/${editandoId}`, form);
        setMensagem('Produto atualizado com sucesso!');
      } else {
        await api.post('/produtos', form);
        setMensagem('Produto cadastrado com sucesso!');
      }
      setForm(ESTADO_INICIAL);
      setEditandoId(null);
      carregarProdutos();
    } catch (err) {
      setMensagem(err.response?.data?.erro || 'Erro ao processar requisição.');
    }
  };

  const handleEditar = (produto) => {
    setForm({
      nome: produto.nome,
      descricao: produto.descricao || '',
      preco: produto.preco,
      codigo_barras: produto.codigo_barras || ''
    });
    setEditandoId(produto.id);
  };

  const handleExcluir = async (id) => {
    if (!window.confirm('Tem certeza que deseja remover este produto?')) return;
    try {
      await api.delete(`/produtos/${id}`);
      setMensagem('Produto removido.');
      carregarProdutos();
    } catch (err) {
      setMensagem('Erro ao excluir produto.');
    }
  };

  return (
    <div>
      <h2>Gerenciamento de Produtos</h2>
      {mensagem && <div className="alert" role="alert">{mensagem}</div>}

      <form onSubmit={handleSubmit}>
        <input name="nome" placeholder="Nome do Produto" value={form.nome} onChange={handleChange} required />
        <input name="descricao" placeholder="Descrição" value={form.descricao} onChange={handleChange} />
        <input name="preco" type="number" step="0.01" min="0" placeholder="Preço (R$)" value={form.preco} onChange={handleChange} required />
        <input name="codigo_barras" placeholder="Código de Barras" value={form.codigo_barras} onChange={handleChange} />

        <button type="submit">{editandoId ? 'Salvar Alterações' : 'Cadastrar'}</button>
        {editandoId && (
          <button
            type="button"
            className="btn-secondary"
            onClick={() => {
              setEditandoId(null);
              setForm(ESTADO_INICIAL);
            }}
          >
            Cancelar
          </button>
        )}
      </form>

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Descrição</th>
            <th>Preço</th>
            <th>Código de Barras</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {produtos.length === 0 ? (
            <tr><td colSpan="6">Nenhum produto cadastrado.</td></tr>
          ) : (
            produtos.map((p) => (
              <tr key={p.id}>
                <td>{p.id}</td>
                <td>{p.nome}</td>
                <td>{p.descricao || '-'}</td>
                <td>R$ {Number(p.preco).toFixed(2)}</td>
                <td>{p.codigo_barras || '-'}</td>
                <td>
                  <button className="btn-edit" onClick={() => handleEditar(p)}>Editar</button>
                  <button className="btn-danger" onClick={() => handleExcluir(p.id)}>Excluir</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Produtos;
