import React, { useState, useEffect } from 'react';
import api from '../services/api';

const ESTADO_INICIAL = { nome: '', cnpj: '', endereco: '', contato: '' };

function Fornecedores() {
  const [fornecedores, setFornecedores] = useState([]);
  const [form, setForm] = useState(ESTADO_INICIAL);
  const [editandoId, setEditandoId] = useState(null);
  const [mensagem, setMensagem] = useState('');

  const carregarFornecedores = async () => {
    try {
      const res = await api.get('/fornecedores');
      setFornecedores(res.data);
    } catch (err) {
      setMensagem('Erro ao buscar fornecedores. Verifique se o backend está em execução.');
    }
  };

  useEffect(() => {
    carregarFornecedores();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editandoId) {
        await api.put(`/fornecedores/${editandoId}`, form);
        setMensagem('Fornecedor atualizado com sucesso!');
      } else {
        await api.post('/fornecedores', form);
        setMensagem('Fornecedor cadastrado com sucesso!');
      }
      setForm(ESTADO_INICIAL);
      setEditandoId(null);
      carregarFornecedores();
    } catch (err) {
      setMensagem(err.response?.data?.erro || 'Erro ao processar fornecedor.');
    }
  };

  const handleEditar = (fornecedor) => {
    setForm({
      nome: fornecedor.nome,
      cnpj: fornecedor.cnpj,
      endereco: fornecedor.endereco || '',
      contato: fornecedor.contato || ''
    });
    setEditandoId(fornecedor.id);
  };

  const handleExcluir = async (id) => {
    if (!window.confirm('Excluir este fornecedor removerá também suas associações. Continuar?')) return;
    try {
      await api.delete(`/fornecedores/${id}`);
      setMensagem('Fornecedor excluído.');
      carregarFornecedores();
    } catch (err) {
      setMensagem('Erro ao excluir.');
    }
  };

  return (
    <div>
      <h2>Gerenciamento de Fornecedores</h2>
      {mensagem && <div className="alert" role="alert">{mensagem}</div>}

      <form onSubmit={handleSubmit}>
        <input name="nome" placeholder="Razão Social / Nome" value={form.nome} onChange={handleChange} required />
        <input name="cnpj" placeholder="CNPJ" value={form.cnpj} onChange={handleChange} required />
        <input name="endereco" placeholder="Endereço" value={form.endereco} onChange={handleChange} />
        <input name="contato" placeholder="Contato / E-mail / Tel" value={form.contato} onChange={handleChange} />

        <button type="submit">{editandoId ? 'Atualizar' : 'Cadastrar'}</button>
        {editandoId && (
          <button
            type="button"
            className="btn-secondary"
            onClick={() => {
              setEditandoId(null);
              setForm(ESTADO_INICIAL);
            }}
          >
            Cancelar
          </button>
        )}
      </form>

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>CNPJ</th>
            <th>Endereço</th>
            <th>Contato</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {fornecedores.length === 0 ? (
            <tr><td colSpan="6">Nenhum fornecedor cadastrado.</td></tr>
          ) : (
            fornecedores.map((f) => (
              <tr key={f.id}>
                <td>{f.id}</td>
                <td>{f.nome}</td>
                <td>{f.cnpj}</td>
                <td>{f.endereco || '-'}</td>
                <td>{f.contato || '-'}</td>
                <td>
                  <button className="btn-edit" onClick={() => handleEditar(f)}>Editar</button>
                  <button className="btn-danger" onClick={() => handleExcluir(f.id)}>Excluir</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Fornecedores;
