import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Produtos from './pages/Produtos';
import Fornecedores from './pages/Fornecedores';
import Associacoes from './pages/Associacoes';
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <header className="header">
        <h1>Faculdade Gran — Projeto Integrador</h1>
        <nav className="nav" aria-label="Navegação principal">
          <Link to="/">Produtos</Link>
          <Link to="/fornecedores">Fornecedores</Link>
          <Link to="/associacoes">Associações (N:N)</Link>
        </nav>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={<Produtos />} />
          <Route path="/fornecedores" element={<Fornecedores />} />
          <Route path="/associacoes" element={<Associacoes />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}

export default App;
